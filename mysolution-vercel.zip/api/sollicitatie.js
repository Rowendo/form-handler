export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ message: "Alleen POST toegestaan" });
  }

  const {
    voornaam,
    tussenvoegsels,
    achternaam,
    email,
    telefoonnummer,
    cvFile,
    utm_source,
    vacatureID
  } = req.body;

  const payload = {
    setApiName: "default",
    status: "Application",
    utm_source,
    fields: {
      Voornaam: { value: voornaam },
      Tussenvoegsels: { value: tussenvoegsels },
      Achternaam: { value: achternaam },
      Email: { value: email },
      Mobiel_nummer: { value: telefoonnummer },
      CV: {
        value: cvFile.base64,
        fileName: cvFile.filename
      },
      PrivacyAgreement: { value: "true" }
    }
  };

  try {
    const response = await fetch(
      `https://freelancersunited.my.salesforce.com/services/apexrest/msf/api/job/Apply?id=${vacatureID}`,
      {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${process.env.MYSOLUTION_TOKEN}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify(payload)
      }
    );

    const result = await response.json();

    if (!response.ok) {
      return res.status(response.status).json({ message: result.message || "Fout bij sollicitatie" });
    }

    return res.status(200).json({ message: "Sollicitatie succesvol verzonden" });
  } catch (err) {
    return res.status(500).json({ message: err.message || "Onbekende fout" });
  }
}
